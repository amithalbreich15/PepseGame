package pepse.world;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.components.CoordinateSpace;
import danogl.gui.rendering.TextRenderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import pepse.Bonus.Dragon;

import java.awt.Color;

/**
 * NumericLifeCounter class - Visual graphic number represents life counter - changing colors accordingly.
 * Also switching colors when life is reducing/increasing:
 *      * Green - 3  or 4 lives remaining
 *      * Yellow - 2 lives remaining
 *      * Red - 1 lives remaining
 */
public class NumericLifeCounter extends GameObject {
    private static final String TEN_LIVES = "10";
    private static final String FIVE_LIVES = "5";
    private static final String SIX_LIVES = "6";
    private static final String  TWO_LIVES = "2";
    private static final String ONE_LIVES = "1";
    private final Counter livesCounter;
    private final TextRenderable renderable;
    private final Avatar avatar;
    private final Dragon dragon;
    /**
     * Construct a new NumericLifeCounter instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param gameObjectCollection      The total Game Objects collection
     */
    public NumericLifeCounter(Counter livesCounter,Vector2 topLeftCorner,
                              Vector2 dimensions,
                              GameObjectCollection gameObjectCollection, Avatar avatar, Dragon dragon) {
        super(topLeftCorner,dimensions,null);
        TextRenderable textRenderable = new TextRenderable("3");
        this.renderer().setRenderable(textRenderable);
        this.renderable = textRenderable;
        this.renderable.setString(String.valueOf(livesCounter.value()));
        this.renderable.setColor(Color.green);
        this.livesCounter = livesCounter;
        this.avatar = avatar;
        this.dragon = dragon;
        this.setCoordinateSpace(CoordinateSpace.CAMERA_COORDINATES);
    }

    /**
     * Increments livesCounter by 1 at a time;
     * @return livesCounter value increased by 1.
     */
    public void decrementLivesCounter() { livesCounter.decrement(); }

    /**
     * Updates the NumericLifeCounter counter on board.
     * Counts down according to current lifeCount remaining for the user to play.
     * Also switching colors when life is reducing:
     * Green - 3 or 4 lives remaining
     * Yellow - 2 lives remaining
     * Red - 1 lives remaining
     * @param deltaTime - Game clock.
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        String numString = "";
//        this.setCenter(avatar.getCenter());
        if (livesCounter.value() >= 0) {
            numString = String.valueOf(livesCounter.value());
            this.renderable.setString(numString);
        }
        switch (numString) {
            case SIX_LIVES:
                this.renderable.setColor(Color.green);
                break;
            case FIVE_LIVES:
            case TWO_LIVES:
                this.renderable.setColor(Color.yellow);
                break;
            case ONE_LIVES:
                this.renderable.setColor(Color.red);
                break;
        }
    }
}

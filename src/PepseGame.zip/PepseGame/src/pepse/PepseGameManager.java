package pepse;

import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.util.Counter;
import danogl.util.Vector2;
import pepse.world.Avatar;
import pepse.world.Sky;
import pepse.world.Terrain;
import pepse.world.daynight.Night;
import pepse.world.daynight.Sun;
import pepse.world.daynight.SunHalo;
import pepse.world.trees.Tree;

import java.awt.*;

public class PepseGameManager extends GameManager {

    private static final int SUN_HALO_LAYER = Layer.BACKGROUND + 10;
    private static final int SUN_LAYER = Layer.BACKGROUND + 1;
    private static final int NIGHT_LAYER = Layer.FOREGROUND;
    private static final int NIGHT_DAY_CYCLE = 30;
    private static final int LEAF_LAYER = Layer.STATIC_OBJECTS + 10;
    private static final int TERRAIN_TOP_LAYER = Layer.STATIC_OBJECTS;
    private static final int AVATAR_LAYER = Layer.DEFAULT;
    private static final int TRUNK_LAYER = Layer.STATIC_OBJECTS + 8;
    private static final int SEED_BOUND = 300;
    private static final int INITIAL_ENERGY = 100;
    private static final int ENERGY_LOCATION = 15;
    private static final int ENERGY_COUNTER_SIZE = 50;
    private static final Color HALO_COLOR = new Color(255, 255, 0, 20);
    private Avatar avatar;
    private int leftBound;
    private int rightBound;
    private Vector2 windowsDimensions;
    private Terrain terrain;
    private Tree tree;
    private Vector2 initialAvatarLocation;
    private Counter energyCounter;

    /**
     * Runs the entire simulation.
     *
     * @param args This argument should not be used.
     */
    public static void main(String[] args) {
        new PepseGameManager().run();
    }

    @Override
    public void initializeGame(ImageReader imageReader, SoundReader soundReader, UserInputListener inputListener,
                               WindowController windowController) {
        super.initializeGame(imageReader, soundReader, inputListener, windowController);
        this.windowsDimensions = windowController.getWindowDimensions();
//        this.initialAvatarLocation = new Vector2(windowController.getWindowDimensions().mult(0.5f));
//        this.rightBound = (int) (initialAvatarLocation.x() + windowController.getWindowDimensions().x());
//        this.leftBound = (int) (initialAvatarLocation.x() - windowController.getWindowDimensions().x());
        Sky.create(gameObjects(), windowsDimensions, Layer.BACKGROUND);

        //create terrain
        Terrain terrain = new Terrain(gameObjects(), Layer.STATIC_OBJECTS, windowsDimensions, 0);
        terrain.createInRange(0,(int)windowsDimensions.x());

        // create Night
        Night.create(gameObjects(), Layer.FOREGROUND, windowsDimensions, 30);

        // create Sun
        GameObject sun = Sun.create(gameObjects(),Layer.BACKGROUND + 1, windowsDimensions, 30);

        // create sun halo
        SunHalo.create(gameObjects(),Layer.BACKGROUND + 2, sun, HALO_COLOR);

        // creates Avatar
        Vector2 avatarLocation = new Vector2(windowsDimensions.x()/2, terrain.groundHeightAt(windowsDimensions.x()/2)-100);
        Avatar.create(gameObjects(), AVATAR_LAYER, avatarLocation, inputListener, imageReader);

    }




}

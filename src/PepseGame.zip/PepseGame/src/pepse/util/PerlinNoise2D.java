package pepse.util;

public class PerlinNoise2D {
}

package pepse.world.trees;

public class Tree {

    public void createInRange(int minX, int maxX) {}
}

package pepse.world;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.ImageReader;
import danogl.gui.UserInputListener;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

public class Avatar extends GameObject {

    private static Avatar instance;
    private static final float WIDTH = 100;
    private static final float HEIGHT = 100;
    private static final String avatarImgPath = "assets/MarioAvatar.png";
    private final UserInputListener inputListener;


    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param renderable    The renderable representing the object. Can be null, in which case
     */
    private Avatar(Vector2 topLeftCorner, Renderable renderable, UserInputListener inputListener) {
        super(topLeftCorner, new Vector2(WIDTH , HEIGHT), renderable);
        this.inputListener = inputListener;
    }


    public static Avatar create(GameObjectCollection gameObjects,
                                int layer, Vector2 topLeftCorner,
                                UserInputListener inputListener,
                                ImageReader imageReader) {
        if(instance == null){
            instance = new Avatar(topLeftCorner,imageReader.readImage(avatarImgPath, true), inputListener);
            gameObjects.addGameObject(instance, layer);
        }
        return instance;


    }
}

package pepse.world;

import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.RectangleRenderable;
import danogl.util.Vector2;
import pepse.util.ColorSupplier;

import java.awt.*;


public class Terrain {
    //todo: maybe add deleteInrange func to avoid overload.

    private static final Color BASE_GROUND_COLOR = new Color(212, 123, 74);
    //private final PerlinNoise perlinNoise;
    private float groundHeightAtX0;
    private GameObjectCollection gameObjects;
    private int groundLayer;
    private Vector2 windowDimensions;


    public Terrain(GameObjectCollection gameObjects, int groundLayer, Vector2 windowDimensions, int seed) {
        this.gameObjects = gameObjects;
        this.groundLayer = groundLayer;
        this.windowDimensions = windowDimensions;
        this.groundHeightAtX0 = windowDimensions.y()*0.8f;
        //this.perlinNoise = new PerlinNoise(seed);
    }

    public float groundHeightAt(float x) {
        //todo: adjust Perlin noise
        return groundHeightAtX0; }

    public void createInRange(int minX, int maxX) {
        float curX = minX;
        while (curX <= maxX){
            createStack((int)Math.floor((windowDimensions.y()-groundHeightAt(curX))/Block.SIZE), (int)curX);
            curX += Block.SIZE;
        }


    }
    private void createStack(int blockAmount, int curX){
        for (int i = 1; i <= blockAmount; i++) {
            Vector2 topleft = new Vector2(curX, windowDimensions.y()-(i*Block.SIZE));
            RectangleRenderable blkRend = new RectangleRenderable(ColorSupplier.approximateColor(BASE_GROUND_COLOR));
            gameObjects.addGameObject(new Block(topleft,blkRend), groundLayer);
        }
    }
}
